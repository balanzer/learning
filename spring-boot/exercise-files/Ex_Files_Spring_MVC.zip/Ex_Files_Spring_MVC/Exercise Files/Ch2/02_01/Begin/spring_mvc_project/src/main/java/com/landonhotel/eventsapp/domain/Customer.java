package com.landonhotel.eventsapp.domain;

public class Customer {
	
	private String lastName;
	private String firstName;
	private String emailAddress;
	private String phoneNumber;
	
	

}

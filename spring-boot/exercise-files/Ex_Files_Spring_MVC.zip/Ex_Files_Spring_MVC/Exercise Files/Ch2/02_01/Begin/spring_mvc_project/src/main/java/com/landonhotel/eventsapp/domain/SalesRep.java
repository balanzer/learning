package com.landonhotel.eventsapp.domain;

public class SalesRep {
	private String lastName;
	private String firstName;
	private String emailAddress;
	private String phoneNumber;
}

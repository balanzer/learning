package com.landonhotel;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class LoggerInterceptor  extends HandlerInterceptorAdapter {
	// add implementation here
}

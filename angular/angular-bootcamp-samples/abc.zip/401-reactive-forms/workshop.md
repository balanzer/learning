# Workshop for this step

* Add an HTML form to the stat filters component, attach a FormGroup
  object to it, and populate it with several reactive form controls.
  Don't forget that you'll need to import the ReactiveFormsModule to
  make Angular's form-handling features available to your application.

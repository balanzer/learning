import { Component } from '@angular/core';

@Component({
  selector: 'payroll-report',
  templateUrl: './payroll-report.component.html'
})
export class PayrollReportComponent { }

# Workshop for this step

1. Make your own variation of the directives here, which animates or
   modifies the behavior of an element.

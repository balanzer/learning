import { Component } from '@angular/core';

@Component({
  selector: 'message-body',
  templateUrl: './message-body.component.html'
})
export class MessageBodyComponent { }

import { Component } from '@angular/core';

@Component({
  selector: 'folder-list',
  templateUrl: './folder-list.component.html'
})
export class FolderListComponent { }

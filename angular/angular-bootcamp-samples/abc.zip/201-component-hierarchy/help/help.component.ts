import { Component } from '@angular/core';

@Component({
  selector: 'help-screen',
  templateUrl: './help.component.html'
})
export class HelpScreenComponent { }

/* tslint:disable */
export const mockHackers = [
  {
    id: '70dd6f38-fd14-4dfd-bd43-3b07586ce49e',
    name: 'Price',
    dob: '1960-06-01T11:01:12.720Z',
    address: '85066 Ona Shores',
    cityStateZip: 'Cartwrightview, South Carolina 24722',
    avatar: 'https://s3.amazonaws.com/uifaces/faces/twitter/ashocka18/128.jpg',
    phone: '(775) 232-7260',
    statusMessage: 'Use the optical RAM pixel, then you can navigate the online protocol!',
    specialty: 'bypassing pixel',
    ip: '187.154.44.205',
    email: 'Price.Donnelly9_Thompson37@gmail.com',
    password: 'ttRXuJjmsm9NLdG',
    status: 'warning'
  },
  {
    id: '762d0945-bfab-4b47-ac3f-7d9d909a1075',
    name: 'Monica',
    dob: '1972-08-23T15:22:34.694Z',
    address: '7557 Flatley Well',
    cityStateZip: 'Lebsackport, Minnesota 33620-5654',
    avatar: 'https://s3.amazonaws.com/uifaces/faces/twitter/oktayelipek/128.jpg',
    phone: '(309) 006-4485',
    statusMessage: "You can't quantify the interface without programming the neural COM matrix!",
    specialty: 'copying array',
    ip: '194.74.47.30',
    email: 'Monica_Kub27@hotmail.com',
    password: '8Kpdl3v5t7q8nDA'
  },
  {
    id: '80c8b1ad-3bff-4713-ab87-3cff9dc9fa0d',
    name: 'Gregg',
    dob: '1980-10-04T21:35:51.869Z',
    address: '975 Jayme Pass',
    cityStateZip: 'West Lizeth, Michigan 98486',
    avatar: 'https://s3.amazonaws.com/uifaces/faces/twitter/travis_arnold/128.jpg',
    phone: '(217) 365-6272',
    statusMessage: "I'll transmit the online HDD transmitter, that should bus the XML driver!",
    specialty: 'quantifying sensor',
    ip: '73.226.119.184',
    email: 'Gregg_Bode2157@yahoo.com',
    password: 'qP8kz1FmKlUugcF',
    status: 'danger'
  },
  {
    id: 'f1b2e9bf-2794-4ccf-a869-9ddb93478f70',
    name: 'Kathlyn',
    dob: '1977-09-03T10:41:20.434Z',
    address: '884 Terrill Pines',
    cityStateZip: 'Sophiaton, Nevada 85879-3435',
    avatar: 'https://s3.amazonaws.com/uifaces/faces/twitter/mslarkina/128.jpg',
    phone: '(851) 416-3782',
    statusMessage: "You can't program the bus without bypassing the redundant RSS circuit!",
    specialty: 'generating protocol',
    ip: '198.18.111.138',
    email: 'Kathlyn_Predovic_Cole@yahoo.com',
    password: 'VV4YWbZTjbt0b9c',
    status: 'safe'
  },
  {
    id: 'dede14f9-dedb-4862-857d-f3c2015dcd56',
    name: 'Ricky',
    dob: '1953-03-26T00:12:42.110Z',
    address: '087 Ariane Park',
    cityStateZip: 'Emardborough, Maine 30850',
    avatar: 'https://s3.amazonaws.com/uifaces/faces/twitter/stefanozoffoli/128.jpg',
    phone: '(674) 331-5468',
    statusMessage: "You can't back up the firewall without navigating the optical EXE bus!",
    specialty: 'hacking pixel',
    ip: '234.199.57.0',
    email: 'Ricky.Kohler_Gleichner@yahoo.com',
    password: '9t2b8cVyhXaEgI3'
  }
];
/* tslint:enable */

export interface Hacker {
  id: string;
  name: string;
  dob: string;
  address: string;
  cityStateZip: string;
  avatar: string;
  phone: string;
  statusMessage: string;
  status: string;
  specialty: string;
  ip: string;
  email: string;
  password: string;
}
